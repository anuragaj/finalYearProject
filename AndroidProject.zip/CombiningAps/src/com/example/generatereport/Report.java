package com.example.generatereport;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import com.example.combiningaps.R;

public class Report extends Activity {
	
public String ip,usn,sem,sec,url_change;
	
	WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_report);
		
		Intent intent = getIntent();
		ip = intent.getStringExtra(MainActivity.IP);
		usn=intent.getStringExtra(MainActivity.USN);
		sem=intent.getStringExtra(MainActivity.SEM);
		sec=intent.getStringExtra(MainActivity.SEC);
		
		url_change = "http://"+ip+"/attendance/generateStudentReport.php?usn="+usn+"&semester="+sem+"&section="+sec;
		
		webView = (WebView) findViewById(R.id.webView1);
		//webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl(url_change);
	}


}
