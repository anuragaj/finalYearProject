package com.example.generatereport;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.example.combiningaps.R;

public class MainActivity extends Activity {
	
	public static final String IP="com.example.generatereport.IP";
	public static final String SEM="com.example.generatereport.sem";
	public static final String SEC="com.example.generatereport.sec";
	public static final String USN="com.example.generatereport.usn";
	
	Button report;
	String ip,usn,sec,sem;
	
	@SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 
        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.generatereport_activity_main);
		Intent intent=getIntent();
		
		 EditText edtxtIp=(EditText)findViewById(R.id.editText4);
		 ip= intent.getStringExtra(com.example.combiningaps.MainActivity.IP);
		 edtxtIp.setText(ip);
		 //ip=edtxtIp.getText().toString();
		 
		report=(Button)findViewById(R.id.button1);
		report.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
                Intent i = new Intent(getApplicationContext(), Report.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtusn=(EditText)findViewById(R.id.editText1);
                EditText edtxtsem=(EditText)findViewById(R.id.editText2);
                EditText edtxtsec=(EditText)findViewById(R.id.editText3);
               
                 usn=edtxtusn.getText().toString();
                 sem=edtxtsem.getText().toString();
                 sec=edtxtsec.getText().toString();
                 //ip=edtxtIp.getText().toString();
                
                	 i.putExtra(IP, ip);
                	 i.putExtra(USN, usn);
                	 i.putExtra(SEM, sem);
                	 i.putExtra(SEC, sec);
                	 startActivity(i);
            	}
            	else
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            }
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
