package com.example.combiningaps;

import com.example.combiningaps.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class Questions extends Activity {
	
	private WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_questions);
		@SuppressWarnings("unused")
		Intent i=getIntent();
		
		final CharSequence sem[] = new CharSequence[7];
		sem[0]="3";
		sem[1]="4";
		sem[2]="5";
		sem[3]="6";
		sem[4]="7";
		sem[5]="8";
		sem[6]="SYLLABUS";
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setTitle("Choose the semester");
    	builder.setItems(sem, new DialogInterface.OnClickListener() {
    	    @Override
    	    public void onClick(DialogInterface dialog, int which) {
    	    	//Toast.makeText(Questions.this, sem[which], Toast.LENGTH_LONG).show();
    	    		
    	    	/*webView = (WebView) findViewById(R.id.webViewquestions);
    			webView.getSettings().setJavaScriptEnabled(true);
    			webView.loadUrl(file:///labprograms);*/
    	    	final int sem=which;
    	    	final CharSequence sub[] = new CharSequence[7];
    	    	switch(which){
    	    	case 0:
    	    		sub[0]="N/A";
    	    		sub[1]="N/A";
    	    		sub[2]="N/A";
    	    		sub[3]="N/A";
    	    		sub[4]="N/A";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 1:
    	    		sub[0]="GT (10CS42)";
    	    		sub[1]="ADA (10CS43)";
    	    		sub[2]="USP (10CS44)";
    	    		sub[3]="MP (10CS45)";
    	    		sub[4]="CO (10CS46)";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 2:
    	    		sub[0]="N/A";
    	    		sub[1]="N/A";
    	    		sub[2]="N/A";
    	    		sub[3]="N/A";
    	    		sub[4]="N/A";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 3:
    	    		sub[0]="M and E (10AL61)";
    	    		sub[1]="USP (10CS62)";
    	    		sub[2]="CD (10CS63)";
    	    		sub[3]="CN 2 (10CS64)";
    	    		sub[4]="CG (10CS65)";
    	    		sub[5]="OR (10CS661)";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 4:
    	    		sub[0]="OOMD (10CS71)";
    	    		sub[1]="ECS (10CS72)";
    	    		sub[2]="PTW (10CS73)";
    	    		sub[3]="ACA (10CS74)";
    	    		sub[4]="N/A";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 5:
    	    		sub[0]="SA (10IS81)";
    	    		sub[1]="SMS (10CS82)";
    	    		sub[2]="WEB 2.0 (10CS832)";
    	    		sub[3]="AD-HOC (10CS841)";
    	    		sub[4]="N/A";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	case 6:
    	    		sub[0]="SYLLABUS COPY";
    	    		sub[1]="N/A";
    	    		sub[2]="N/A";
    	    		sub[3]="N/A";
    	    		sub[4]="N/A";
    	    		sub[5]="N/A";
    	    		sub[6]="N/A";
    	    		break;
    	    	default:

    	    		
    	    	}
    			
    			AlertDialog.Builder builder1 = new AlertDialog.Builder(Questions.this);
    	    	builder1.setTitle("Choose the subject");
    	    	builder1.setItems(sub, new DialogInterface.OnClickListener() {
    	    	    @Override
    	    	    public void onClick(DialogInterface dialog, int which) {
    	    	    	//Toast.makeText(Questions.this, sub[which], Toast.LENGTH_LONG).show();
    	    	    		
    	    	    	String url=null;
    	    	    	webView = (WebView) findViewById(R.id.webViewquestions);
    	    			//webView.getSettings().setJavaScriptEnabled(true);
    	    			//webView.loadUrl(file:///labprograms);
    	    	    	switch(sem){
    	    	    	case 0:url="file:///android_asset/na.html";
    	    	    	webView.loadUrl(url);
    	    	    		break;
    	    	    	case 1:
    	    	    		if(which==0)
    	    	    			url="file:///android_asset/10CS42.html";
    	    	    		else if(which==1)
    	    	    			url="file:///android_asset/10CS43.html";
    	    	    		else if(which==2)
    	    	    			url="file:///android_asset/10CS44.html";
    	    	    		else if(which==3)
    	    	    			url="file:///android_asset/10CS45.html";
    	    	    		else if(which==4)
    	    	    			url="file:///android_asset/10CS46.html";
    	    	    		webView.loadUrl(url);
    	    	    		break;
    	    	    	case 2:url="file:///android_asset/na.html";
    	    	    	webView.loadUrl(url);
    	    	    		break;
    	    	    	case 3:
    	    	    		if(which==0)
	    	    			url="file:///android_asset/10AL61.html";
	    	    		else if(which==1)
	    	    			url="file:///android_asset/10CS62.html";
	    	    		else if(which==2)
	    	    			url="file:///android_asset/10CS63.html";
	    	    		else if(which==3)
	    	    			url="file:///10CS64.html";
	    	    		else if(which==4)
	    	    			url="file:///android_asset/10CS65.html";
	    	    		else if(which==5)
	    	    			url="file:///android_asset/10CS661.html";
	    	    		webView.loadUrl(url);
    	    	    		break;
    	    	    	case 4:
    	    	    		if(which==0)
    	    	    			url="file:///android_asset/10CS71.html";
    	    	    		else if(which==1)
    	    	    			url="file:///android_asset/10CS72.html";
    	    	    		else if(which==2)
    	    	    			url="file:///android_asset/10CS73.html";
    	    	    		else if(which==3)
    	    	    			url="file:///android_asset/10CS74.html";
    	    	    		webView.loadUrl(url);
    	    	    		break;
    	    	    	case 5:
    	    	    		if(which==0)
    	    	    			url="file:///android_asset/10IS81.html";
    	    	    		else if(which==1)
    	    	    			url="file:///android_asset/10CS82.html";
    	    	    		else if(which==2)
    	    	    			url="file:///android_asset/10CS832.html";
    	    	    		else if(which==3)
    	    	    			url="file:///android_asset/10CS841.html";
    	    	    		webView.loadUrl(url);
    	    	    		break;
    	    	    	case 6:
    	    	    		url="file:///android_asset/sc.html";
    	    	    		webView.loadUrl(url);
    	    	    		break;
    	    	    		
    	    	    		
    	    	    	}
    	    	       
    	    	    }
    	    	});
    	    	builder1.show();
    	       
    	    }
    	});
    	builder.show();
    	
    	
	}


}
