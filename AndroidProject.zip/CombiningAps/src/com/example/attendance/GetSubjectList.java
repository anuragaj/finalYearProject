package com.example.attendance;

public class GetSubjectList {

}
