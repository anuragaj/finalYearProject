-- phpMyAdmin SQL Dump
-- version 3.5.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 28, 2015 at 05:51 PM
-- Server version: 5.5.29
-- PHP Version: 5.4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `SIET`
--
CREATE DATABASE `SIET` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `SIET`;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `USN` varchar(10) NOT NULL,
  `subjectCode` varchar(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `attendance` varchar(1) NOT NULL,
  `Rollno` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `semester` int(1) DEFAULT NULL,
  `section` varchar(1) DEFAULT NULL,
  `subjectCode` varchar(10) NOT NULL,
  `count` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`semester`, `section`, `subjectCode`, `count`) VALUES
(8, 'A', '10IS81', 0),
(8, 'B', '10IS81', 0),
(8, 'A', '10CS82', 0),
(8, 'B', '10CS82', 0),
(8, 'A', '10CS831', 0),
(8, 'A', '10CS832', 0),
(8, 'B', '10CS831', 0),
(8, 'B', '10CS832', 0),
(8, 'A', '10CS841', 0),
(8, 'B', '10CS841', 0),
(7, 'A', '10CS71', 0),
(7, 'B', '10CS71', 0),
(7, 'A', '10CS72', 0),
(7, 'B', '10CS72', 0),
(7, 'A', '10CS73', 0),
(7, 'B', '10CS73', 0),
(7, 'A', '10CS74', 0),
(7, 'B', '10CS74', 0),
(7, 'A', '10CS751', 0),
(7, 'B', '10CS751', 0),
(7, 'A', '10CS761', 0),
(7, 'B', '10CS761', 0),
(6, 'A', '10AL61', 0),
(6, 'B', '10AL61', 0),
(6, 'A', '10CS62', 0),
(6, 'B', '10CS62', 0),
(6, 'A', '10CS63', 0),
(6, 'B', '10CS63', 0),
(6, 'A', '10CS64', 0),
(6, 'B', '10CS64', 0),
(6, 'A', '10CS65', 0),
(6, 'B', '10CS65', 0),
(6, 'A', '10CS661', 0),
(6, 'B', '10CS661', 0),
(5, 'A', '10IS51', 0),
(5, 'B', '10IS51', 0),
(5, 'A', '10CS52', 0),
(5, 'B', '10CS52', 0),
(5, 'A', '10CS53', 0),
(5, 'B', '10CS53', 0),
(5, 'A', '10CS54', 0),
(5, 'B', '10CS54', 0),
(5, 'A', '10CS56', 0),
(5, 'B', '10CS56', 0),
(5, 'A', '10CS55', 0),
(5, 'B', '10CS55', 0),
(4, 'A', '10MAT41', 0),
(4, 'B', '10MAT41', 0),
(4, 'A', '10CS42', 0),
(4, 'B', '10CS42', 0),
(4, 'A', '10CS43', 0),
(4, 'B', '10CS43', 0),
(4, 'A', '10CS44', 0),
(4, 'B', '10CS44', 0),
(4, 'A', '10CS45', 0),
(4, 'B', '10CS45', 0),
(4, 'A', '10CS46', 0),
(4, 'B', '10CS46', 0),
(3, 'A', '10MAT31', 0),
(3, 'B', '10MAT31', 0),
(3, 'A', '10CS32', 0),
(3, 'B', '10CS32', 0),
(3, 'A', '10CS33', 0),
(3, 'B', '10CS33', 0),
(3, 'A', '10CS34', 0),
(3, 'A', '10CS35', 0),
(3, 'B', '10CS35', 0),
(3, 'A', '10CS36', 0),
(3, 'B', '10CS36', 0),
(3, 'B', '10CS34', 0);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `subject` varchar(30) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `createdat` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`subject`, `content`, `createdat`) VALUES
('Tomorrow classes are postponed', 'Tomorrow classes are been postponed.The postponed date will been announced later.', '05/09/2014 03:43:49 '),
('Tomorrow classes are postponed', 'Tomorrow classes are been postponed.The postponed date will been announced later.', '05/09/2014 03:44:19 ');

-- --------------------------------------------------------

--
-- Table structure for table `staffDetails`
--

CREATE TABLE `staffDetails` (
  `staffID` varchar(3) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `passcode` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffDetails`
--

INSERT INTO `staffDetails` (`staffID`, `Name`, `passcode`) VALUES
('1', 'D A VIJAYARAGHAVAN', '001'),
('2', 'SHANMUKA SWAMY', '002'),
('3', 'JAYANTHKUMAR A RATHOD', '003'),
('4', 'MANJUNATH H R ', '004'),
('7', 'PRASANNAKUMAR', '007'),
('8', 'RENUKARADHYA P C', '008'),
('9', 'SOMASHEKHAR B M', '009'),
('10', 'BASAVESHA C', '010'),
('11', 'RAGHUNANDAN', '011'),
('12', 'MANOHARA P H', '012'),
('13', 'SHOBHA M', '013'),
('14', 'KIRAN G M', '014'),
('15', 'SUTAN R', '015'),
('17', 'UMESH B L', '016'),
('18', 'VENUGOPAL D', '017'),
('19', 'SHILPA SANNAMANI', '019'),
('20', 'T M SIDDESH', '020'),
('21', 'SUPRA G S', '021'),
('22', 'CHETANA M S', '022'),
('23', 'MALLESH H L', '023'),
('24', 'SWETHA K H', '024'),
('25', 'RAGHAVENDRA N', '025'),
('26', 'ARAVIND REDDY', '026'),
('27', 'SATISH C A', '027'),
('28', 'BEENA G PILLAI', '028'),
('29', 'YOGAMBIKA C M', '029'),
('30', 'PRUTHVI L S', '030'),
('31', 'SOWMYA D R', '031');

-- --------------------------------------------------------

--
-- Table structure for table `studentDetails`
--

CREATE TABLE `studentDetails` (
  `USN` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `semester` varchar(1) NOT NULL,
  `section` varchar(1) NOT NULL,
  `rollNo` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`USN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentDetails`
--

INSERT INTO `studentDetails` (`USN`, `name`, `semester`, `section`, `rollNo`) VALUES
('1sv08cs045', 'Lavanya Rani K P', '6', 'A', '1'),
('1sv08cs102', 'Suraj T P', '6', 'A', '2'),
('1sv10cs001', 'AbrarM', '6', 'A', '3'),
('1sv10cs003', 'Akashata C M', '8', 'A', '1'),
('1sv10cs004', 'anurag ajoshi', '8', 'A', '11'),
('1sv10cs007', 'Arpita Dev', '8', 'A', '3'),
('1sv10cs023', 'Guruprasad', '8', 'A', '4'),
('1sv10cs025', 'Harikrishna', '8', 'A', '5'),
('1sv10cs029', 'Jayesh M', '6', 'A', '4'),
('1sv10cs039', 'Likith A Nazare', '8', 'A', '6'),
('1sv10cs040', 'Manjunatha B S', '8', 'A', '7'),
('1sv10cs042', 'Mareepa', '8', 'A', '8'),
('1sv10cs043', 'Meghana K Murthy', '8', 'A', '9'),
('1sv10cs045', 'Nagaraj T V', '8', 'A', '10'),
('1sv10cs065', 'Rekha D H', '8', 'B', '11'),
('1sv10cs066', 'Sachin B M', '8', 'B', '12'),
('1sv10cs067', 'Sahana K N', '8', 'B', '13'),
('1sv10cs075', 'Shilpa R', '8', 'B', '14'),
('1sv10cs077', 'Shreyas S', '8', 'B', '15'),
('1sv10cs079', 'Shruthi T M', '8', 'B', '16'),
('1sv10cs081', 'Sindu B A', '8', 'B', '17'),
('1sv10cs082', 'Sowmya B', '8', 'B', '18'),
('1sv10cs084', 'Sumalakshmi C D', '8', 'B', '19'),
('1sv10cs086', 'Sweta Kumari', '8', 'B', '20'),
('1sv11cs015', 'Bundu A', '6', 'A', '5'),
('1sv11cs017', 'Chaitra T K', '6', 'A', '6'),
('1sv11cs018', 'Divya K R', '6', 'A', '7'),
('1sv11cs020', 'Gowthami M K', '6', 'A', '8'),
('1sv11cs027', 'Shruthi s K', '6', 'A', '9'),
('1sv11cs029', 'Kumar D H', '6', 'A', '10'),
('1sv11cs071', 'Sindhu J', '4', 'A', '1'),
('1sv11cs082', 'Surya Teja H P', '6', 'B', '11'),
('1sv11cs083', 'Sushmitha B', '6', 'B', '12'),
('1sv11cs084', 'Tony Vincent T Y', '6', 'B', '13'),
('1sv11cs085', 'Uzma Shaheen', '6', 'B', '14'),
('1sv11cs087', 'Vidyashree H S', '6', 'B', '15'),
('1sv11cs090', 'Vinod Kumar P ', '6', 'B', '16'),
('1sv11cs093', 'VishnuPriya G U', '6', 'B', '17'),
('1sv11cs400', 'Anil', '6', 'B', '20'),
('1sv11cs405', 'Krishna', '6', 'B', '18'),
('1sv11cs410', 'Siddarajaiah D C', '6', 'B', '19'),
('1sv12cs002', 'Akash S Pillai', '4', 'A', '2'),
('1sv12cs009', 'Bharath N', '4', 'A', '3'),
('1sv12cs011', 'Bhavyashree MP', '4', 'A', '4'),
('1sv12cs014', 'Deepak Kumar', '4', 'A', '9'),
('1sv12cs017', 'Divyashree A S', '4', 'A', '10'),
('1sv12cs086', 'Swathi G', '4', 'B', '17'),
('1sv12cs087', 'Swetha K', '4', 'B', '18'),
('1sv12cs090', 'Thejaswini T M', '4', 'B', '19'),
('1sv12cs092', 'Vaishhavi N', '4', 'B', '20'),
('1sv12cs093', 'Varun T P', '4', 'B', '11'),
('1sv12cs094', 'Vikas R', '4', 'B', '12'),
('1sv12cs095', 'Vinutha A P', '4', 'B', '13'),
('1sv12cs097', 'Vishnu N', '4', 'B', '14'),
('1sv12cs101', 'Yashasvini H J', '4', 'B', '15'),
('1sv12cs102', 'Yogashree K H', '4', 'B', '16'),
('1sv13cs401', 'Lakshmi S', '4', 'A', '5'),
('1sv13cs404', 'Manjunath C', '4', 'A', '6'),
('1sv13cs406', 'Nemathullakhah', '4', 'A', '7'),
('1sv13cs407', 'Nishitha S', '4', 'A', '8');

-- --------------------------------------------------------

--
-- Table structure for table `subjectDetails`
--

CREATE TABLE `subjectDetails` (
  `subjectCode` varchar(10) NOT NULL,
  `subjectName` varchar(50) NOT NULL,
  `semester` int(1) NOT NULL,
  PRIMARY KEY (`subjectCode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectDetails`
--

INSERT INTO `subjectDetails` (`subjectCode`, `subjectName`, `semester`) VALUES
('10AL61', 'M AND E', 6),
('10CS32', 'ELECTRONICS CIRCUITS', 3),
('10CS33', 'LOGIC DESIGN', 3),
('10CS34', 'DMS', 3),
('10CS35', 'DSC', 3),
('10CS36', 'OOPS', 3),
('10CS42', 'GTC', 4),
('10CS43', 'ADA', 4),
('10CS44', 'USP', 4),
('10CS45', 'MP', 4),
('10CS46', 'CO', 4),
('10CS52', 'SS', 5),
('10CS53', 'OS', 5),
('10CS54', 'DBMS', 5),
('10CS55', 'CN1', 5),
('10CS56', 'FLAT', 5),
('10CS62', 'USP', 6),
('10CS63', 'CD', 6),
('10CS64', 'CD', 6),
('10CS65', 'CG', 6),
('10CS661', 'OR', 6),
('10CS71', 'OOMD', 7),
('10CS72', 'ECS', 7),
('10CS73', 'PTW', 7),
('10CS74', 'ACA', 7),
('10CS753', 'JAVA AND J2EE', 7),
('10CS761', 'C AND DOT NET', 7),
('10CS82', 'SMS', 8),
('10CS831', 'MC', 8),
('10CS832', 'WEB2', 8),
('10CS841', 'ADHOC NETWORKS', 8),
('10IS51', 'SE', 5),
('10IS81', 'SA', 8),
('10MAT31', 'ENGINEERING MATHS 3', 3),
('10MAT41', 'ENGINEERING MATHS 4', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
