<?php

$si=$_GET["si"];
$op=$_GET["op"];
$np=$_GET["np"];

require_once __DIR__ . '/db_connect.php';

            $db = new DB_CONNECT();

            $result=mysql_query("SELECT * FROM staffDetails WHERE staffID='$si' AND passcode='$op'")or die(mysql_error("error"));

            if(mysql_num_rows($result) > 0) {

            	if(mysql_num_rows($result) < 2){
            	$result=mysql_query("UPDATE staffDetails SET passcode='$np' WHERE passcode='$op'")or die(mysql_error());

            	echo "PASSCODE CHANGED";
            }
            else

            	echo "passcode is not valid, please choose different one";

            }
            else
            	echo "Staff id or old passcode is not valid";


?>