<!DOCTYPE html>
 <head>
   <meta charset="utf-8" />
   <link rel="stylesheet" type="text/css" href="./smscss.css"/>
  </head>
  <body><div id="container">
    <table align="center" cellspacing="5" celpadding="10">
        <tr>
        <th> SUBJECT CODE</th>
        <th> USN </th>
        <th> NUMBER OF CLASSES CONDUCTED </th>
        <th> NUMBER OF CLASSES ATTENDED </th>
        <th> PERCENTAGE </th>
    </tr>
<?php
	if($_POST){
	$subject=$_POST['subjectCode'];
    $section=$_POST['section'];
    $semester=$_POST['semester'];
}
if($_GET){
    $subject=$_GET['subjectCode'];
    $section=$_GET['section'];
    $semester=$_GET['semester'];
}



//echo "<tr><td>$subject</td><td>$section</td><td>$semester</td>";

	require_once __DIR__ . '/db_connect.php';

    $db = new DB_CONNECT();

        $result0=mysql_query("SELECT * FROM studentDetails WHERE semester='$semester' AND section='$section'")or die(mysql_error());

        $rows=mysql_num_rows($result0);

        echo "<tr align='center'>
                            <td rowspan='$rows'>$subject</td>";

    if(mysql_num_rows($result0) > 0) {
                while ($row0 = mysql_fetch_array($result0)) {
                    $u=$row0['USN']."\n(".$row0['name'].")";
                    $u1=$row0['USN'];
                        $result2=mysql_query("SELECT count FROM class WHERE semester='$semester' AND section='$section' AND subjectCode='$subject'")or die(mysql_errno());
                        $row2=mysql_fetch_array($result2);
                        $c=$row2['count'];
                        $result3=mysql_query("SELECT * FROM attendance WHERE USN='$u1' AND subjectCode='$subject' AND attendance='t'")or die(mysql_errno());
                        $row3=mysql_num_rows($result3);
                        $a=$row3;

                        $p=$a/$c;
                        $p=$p*100;
                        $p=$p."  %";
                        echo "  <td align='center'>$u</td>
                                <td align='center'>$c</td>
                                <td align='center'>$a</td>
                                <td align='center'>$p</td>
                                </tr>";
                        //echo "<br/>";

                    }
                    //echo $u."\t";

            }



 ?>
</table>
</div>
</body>
</html>




