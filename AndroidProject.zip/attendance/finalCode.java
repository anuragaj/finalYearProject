package com.example.addnotificationdifferent;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class AddNotificationDifferent extends Activity {

	public String current_ip;
	public String passcode;
	public String url_all_students;
    public String s,c,pc;
    
    private WebView webView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_notification_different);
		
		Intent intent = getIntent();
		current_ip = intent.getStringExtra(MainActivity.IP);
		s=intent.getStringExtra(MainActivity.SUB);
		c=intent.getStringExtra(MainActivity.CONTENT);
		pc=intent.getStringExtra(MainActivity.PC);
		
		url_all_students = "http://"+current_ip+"/attendance/addNotificationMobile.php?s="+s+"&c="+c+"&pc="+pc;
		
		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl(url_all_students);
	}

}
package com.example.addnotificationdifferent;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectionDetector {
	private Context _context;
    
    public ConnectionDetector(Context context){
        this._context = context;
    }
 
    public boolean isConnectingToInternet(){
        ConnectivityManager connectivity = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
          if (connectivity != null)
          {
              NetworkInfo[] info = connectivity.getAllNetworkInfo();
              if (info != null)
                  for (int i = 0; i < info.length; i++)
                      if (info[i].getState() == NetworkInfo.State.CONNECTED)
                      {
                          return true;
                      }
 
          }
          return false;
    }

}
package com.example.addnotificationdifferent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	
	public static final String IP="com.example.AddNotification.IP";
	public static final String SUB="com.example.AddNotification.SUB";
	public static final String CONTENT="com.example.AddNotification.CONTENT";
	public static final String PC="com.example.AddNotification.PC";
	Button btnAddNotification;
	public String pc;
	public String ip;
	public String sub;
	public String content;
	
	public void displayToast(String s){
		 Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
	 }
	
	@SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
       AlertDialog alertDialog = new AlertDialog.Builder(context).create();

       // Setting Dialog Title
       alertDialog.setTitle(title);

       // Setting Dialog Message
       alertDialog.setMessage(message);
        
       // Setting alert dialog icon
       //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

       // Setting OK Button
       alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
           @Override
			public void onClick(DialogInterface dialog, int which) {
           }
       });

       // Showing Alert Message
       alertDialog.show();
   }
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
btnAddNotification=(Button)findViewById(R.id.button1);
		
		btnAddNotification.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	//displayToast("Within");
            
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            	
            	EditText edtxtIp=(EditText)findViewById(R.id.editText3);
            	ip=edtxtIp.getText().toString();
            	
            	EditText edtxts=(EditText)findViewById(R.id.editText1);
            	sub=edtxts.getText().toString();
            	
            	EditText edtxtc=(EditText)findViewById(R.id.editText2);
            	content=edtxtc.getText().toString();
            	//displayToast(ip+"  "+sub+"  "+content);
            	//display input alert dialog
            	AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        		builder.setTitle("ENTER PASSCODE");

        		// Set up the input
        		final EditText input = new EditText(MainActivity.this);
        		// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        		input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        		builder.setView(input);

        		// Set up the buttons
        		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { 
        		    @Override
        		    public void onClick(DialogInterface dialog, int which) {
        		        pc = input.getText().toString();
        		        Intent i = new Intent(getApplicationContext(),AddNotificationDifferent.class);
                        
                        i.putExtra(IP, ip);
                        i.putExtra(PC, pc);
                        i.putExtra(SUB, sub);
                        i.putExtra(CONTENT, content);
                        startActivity(i);
        	
        		    }
        		});
        		builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
        		    @Override
        		    public void onClick(DialogInterface dialog, int which) {
        		        dialog.cancel();
        		    }
        		});

        		builder.show();
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
                
	}

}
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/LinearLayout1"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:paddingBottom="@dimen/activity_vertical_margin"
    android:paddingLeft="@dimen/activity_horizontal_margin"
    android:paddingRight="@dimen/activity_horizontal_margin"
    android:paddingTop="@dimen/activity_vertical_margin"
    tools:context=".MainActivity" >

    <EditText
        android:id="@+id/editText1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="subject"
        android:singleLine="true" >

        <requestFocus />
    </EditText>

    <EditText
        android:id="@+id/editText2"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="content"
        android:inputType="textMultiLine"
        android:singleLine="false" />

    <EditText
        android:id="@+id/editText3"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="IP" />

    <Button
        android:id="@+id/button1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="ADD" />

</LinearLayout>
<?xml version="1.0" encoding="utf-8"?>
<WebView xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/webView1"
    android:layout_width="match_parent"
    android:layout_height="match_parent" />
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.addnotificationdifferent"
    android:versionCode="1"
    android:versionName="1.0" >

    <!-- Internet Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />

    <!-- Network State Permissions -->
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <uses-sdk
        android:minSdkVersion="8"
        android:targetSdkVersion="18" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme" >
        <activity
            android:name="com.example.addnotificationdifferent.MainActivity"
            android:label="@string/app_name" >
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity
            android:name="com.example.addnotificationdifferent.AddNotificationDifferent"
            android:label="@string/title_activity_add_notification_different" >
        </activity>
    </application>

</manifest>
package com.example.attendance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class GetStudentList extends ListActivity {
	
	class Student{
		String name;
		String usn;
		String section;
		String semester;
		String rollno;
		boolean attendance;
		
	 Student(){
			attendance=false;
		}
	}
	
	 class Subject{
		String subjectName;
		String subjectCode;
	}
	
	 class Staff{
		String name;
		String passcode;
	}
	
	 Student[] peers;
	 Subject[] subs;
	 Staff[] lecturers;
	 int code=0;
	 int subCode;
	
	int numberOfStudents=0;
	int numberOfSubjects=0;
	int numberOfStaff=0;
	
	int currentStudent=0;
	public String current_ip;
	String passcode;
	
	private ProgressDialog pDialog;
	 
    JSONParser jParser = new JSONParser();
    JSONParser jp=new JSONParser();
 
    ArrayList<HashMap<String, String>> studentList;
  
    public String url_all_students;
    public String url_verify_passcode;
    public String url_update;
    public String sem,sec;

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_STUDENTS = "students";
    private static final String TAG_USN= "usn";
    private static final String TAG_NAME = "name";
    private static final String TAG_ROLLNO="rollno";
    private static final String TAG_SUBJECTS="subjects";
    private static final String TAG_SUBJECTNAME="subjectName";
    private static final String TAG_SUBJECTCODE="subjectCode";
    private static final String TAG_STAFF="lecturers";
    private static final String TAG_PASSCODE="passcode";
    
    public static final String URL="com.example.Attendance.URL";
	
    
    private WebView webView;
    
 
    // products JSONArray
    JSONArray students = null;
    JSONArray subjects = null;
    JSONArray staff = null;
    
    public void displayToast(String s){
		 Toast.makeText(this, s, Toast.LENGTH_LONG).show();
	 }
    public void displayToast(int s){
		 Toast.makeText(GetStudentList.this, s, Toast.LENGTH_LONG).show();
	 }
    @SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 
        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }


    public void displayAlert(String s){
    	new AlertDialog.Builder(this)
        .setTitle("CONTENT")
        .setMessage(s)
        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) { 
                // continue with delete
            }
         })
         .show();
    	
    }
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_get_student_list);
		
		Intent intent = getIntent();
		current_ip = intent.getStringExtra(MainActivity.IP);
		sem=intent.getStringExtra(MainActivity.SEM);
		sec=intent.getStringExtra(MainActivity.SEC);
		
		url_all_students = "http://"+current_ip+"/attendance/getStudentList.php?sem="+sem+"&sec="+sec;
		
		studentList = new ArrayList<HashMap<String, String>>();

        new LoadAllStudents().execute();
		
		 ListView lv = getListView();
		 
		 lv.setOnItemClickListener(new OnItemClickListener() {
		 @Override
         public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
			 
			 //TextView p=(TextView)view.findViewById(R.id.present);
			 TextView t=(TextView)view.findViewById(R.id.rollno);
			 String s=(String) t.getText();
			 int found=1;
			 for(int j=0;j<numberOfStudents && found==1;j++){
				 if(peers[j].rollno.equals(s)){
					 currentStudent=j;
					 found=0;
					 }
					 
			 }
			 if(found==0){
				//displayToast(""+currentStudent);
			 if(peers[currentStudent].attendance){
				 
				 //p.setText("Absent "+currentStudent);
				 peers[currentStudent].attendance=false;
				 
			 }
			 else{
				 //p.setText("Present "+currentStudent);
				 peers[currentStudent].attendance=true;
				 //t.setTextColor(color.holo_green_dark);
				 
				 
			 }
		 }
			 
		 }
     });
		 }
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // if result code 100
        if (resultCode == 100) {
            // if result code 100 is received
            // means user edited/deleted product
            // reload this screen again
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
 
    }
	class LoadAllStudents extends AsyncTask<String, String, String> {
		 
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(GetStudentList.this);
            pDialog.setMessage("Loading students. Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
 
        /**
         * getting All products from url
         * */
        @Override
		protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            JSONObject json = jParser.makeHttpRequest(url_all_students,"POST",params);

            Log.d("All Students: ", json.toString());
 
            try {
                int success = json.getInt(TAG_SUCCESS);
               
                if (success == 1) {
                    students = json.getJSONArray(TAG_STUDENTS);
                    subjects = json.getJSONArray(TAG_SUBJECTS);
                    staff=json.getJSONArray(TAG_STAFF);
                    numberOfSubjects=subjects.length();
                    numberOfStudents=students.length();
                    numberOfStaff=staff.length();
                    
                    peers=new Student[numberOfStudents];
 
                    for (int i = 0; i < students.length(); i++) {
                    	
                    	peers[i]=new Student();
                        JSONObject c = students.getJSONObject(i);
 
                        // Storing each json item in variable
                        String usn = c.getString(TAG_USN);
                        String name = c.getString(TAG_NAME);
                        String rollno = c.getString(TAG_ROLLNO);
 
                        // creating new HashMap
                        HashMap<String, String> map = new HashMap<String, String>();
 
                        // adding each child node to HashMap key => value
                        map.put(TAG_USN, usn);
                        map.put(TAG_NAME,name);
                        map.put(TAG_ROLLNO,rollno);
                       
                        studentList.add(map);
                        
                        peers[i].name=name;
                        peers[i].semester=sem;
                        peers[i].section=sec;
                        peers[i].rollno=rollno;
                        peers[i].usn=usn;
                    }
                    subs=new Subject[numberOfSubjects];
                    
                    for (int i = 0; i < subjects.length(); i++) {
                    	
                    	subs[i]=new Subject();
                        JSONObject c = subjects.getJSONObject(i);
 
                        // Storing each json item in variable
                        subs[i].subjectCode= c.getString(TAG_SUBJECTCODE);
                        subs[i].subjectName = c.getString(TAG_SUBJECTNAME);
                    }
                    
                    lecturers=new Staff[numberOfStaff];
                    
                    for (int i = 0; i < staff.length(); i++) {
                    	
                    	lecturers[i]=new Staff();
                        JSONObject c = staff.getJSONObject(i);
 
                        // Storing each json item in variable
                        lecturers[i].name= c.getString(TAG_NAME);
                        lecturers[i].passcode = c.getString(TAG_PASSCODE);
                    }
                    
                }
                else{
                	displayToast(success);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        	
 
            return null;
        }
 
        /**
         * After completing background task Dismiss the progress dialog
         * **/
        @Override
		protected void onPostExecute(String file_url) {
            // dismiss the dialog after getting all products
            pDialog.dismiss();
            // updating UI from Background Thread
            runOnUiThread(new Runnable() {
                @Override
				public void run() {
                    /**
                     * Updating parsed JSON data into ListView
                     */
                    ListAdapter adapter = new SimpleAdapter(
                            GetStudentList.this, studentList,
                            R.layout.list_item, new String[] { TAG_USN,
                                    TAG_NAME,TAG_ROLLNO},
                            new int[] { R.id.usn, R.id.name,R.id.rollno });
                    // updating listview
                    setListAdapter(adapter);
                }
            });
        }
 
    }
	class Update{
		 
public void execute(){
			displayToast("updated");


        }
 
    }
	@Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.layout.menu, menu);
        return true;
    }
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item){
         
        switch (item.getItemId())
        {
        case R.id.finalSubmit:		
        	final CharSequence subjects[] = new CharSequence[numberOfSubjects];
        	
        	for(int i=0;i<numberOfSubjects;i++)
        		subjects[i]=subs[i].subjectCode+"\t"+subs[i].subjectName;
        	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setTitle("Choose the suject");
        	builder.setItems(subjects, new DialogInterface.OnClickListener() {
        	    @Override
        	    public void onClick(DialogInterface dialog, int which) {
        	        submit(which);
        	        subCode=which;
        	       
        	    }
        	});
        	builder.show();
        	return true;
        
        case R.id.showSelection:
        	String main="";
        	for(int i=0;i<numberOfStudents;i++){
        		main+=peers[i].name+" "+peers[i].attendance+"\n";
        	}
        	showAlertDialog(GetStudentList.this,"attendance",main,false);
        	return true;
        	
        /*case R.id.showStaff:
        	String m="";
        	for(int i=0;i<numberOfStaff;i++){
        		m+=lecturers[i].name+" "+lecturers[i].passcode+"\n";
        	}
        	
        	showAlertDialog(GetStudentList.this,"staff",m,false);
        	return true;
        	*/
        default:
            return super.onOptionsItemSelected(item);
        }
		
    }
	protected void submit(int which) {
		passcode=null;
	
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("ENTER PASSCODE");

		// Set up the input
		final EditText input = new EditText(this);
		// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
		input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		builder.setView(input);

		// Set up the buttons
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { 
		    @SuppressLint("SetJavaScriptEnabled")
			@Override
		    public void onClick(DialogInterface dialog, int which) {
		        passcode = input.getText().toString();
		        int found=0;
		        for(int i=0;i<staff.length() && found==0;i++){
		        	if(lecturers[i].passcode.equals(passcode))
		        		found=1;
		        }
		        if(found==1){
		        	//displayAlert("valid passcode");
		        	
		        	String url_update = null;
		        	
		        	
		    		//process the URL
		    		// add address, students,number of students, increase the count 
		    		url_update="http://"+current_ip+"/attendance/addStudentsDifferent.php?";
		    		for(int i=0;i<numberOfStudents;i++){
		    			url_update+="&sn"+i+"="+peers[i].name+"&sr"+i+"="+peers[i].rollno+
		    					"&su"+i+"="+peers[i].usn+"&sa"+i+"="+peers[i].attendance;
		    		}			
		    		
		    		url_update+="&section"+"="+peers[0].section+"&semester"+"="+peers[0].semester;
		    		url_update+="&numberOfStudents="+numberOfStudents;
		    		url_update+="&subjectCode="+subs[0].subjectCode;
		    	
		    		url_update=url_update.replaceAll("\\s", "+");
		    		
		    		//displayAlert(url_update);
		    		Intent i = new Intent(getApplicationContext(), ShowResult.class);
		    		i.putExtra(URL,url_update);
		    		startActivity(i);
		    		}
		        else
		        	displayAlert("Invalid passcode");
	
		    }
		});
		builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
		    @Override
		    public void onClick(DialogInterface dialog, int which) {
		        dialog.cancel();
		    }
		});

		builder.show();
		

		//increment the student list in database
		
	}
}

package com.example.attendance;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;
 
public class JSONParser {
 
    static InputStream is = null;
    static JSONObject jObj = null;
    static String json = "";
 
    // constructor
    public JSONParser() {
 
    }
 
    // function get json from url
    // by making HTTP POST or GET mehtod
    public JSONObject makeHttpRequest(String url, String method,
            List<NameValuePair> params) {
 
        // Making HTTP request
        try {
 
            // check for request method
            if(method == "POST"){
                // request method is POST
                // defaultHttpClient
                DefaultHttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost(url);
                httpPost.setEntity(new UrlEncodedFormEntity(params));
 
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                is = httpEntity.getContent();
 
            }else if(method == "GET"){
                // request method is GET
                DefaultHttpClient httpClient = new DefaultHttpClient();
                String paramString = URLEncodedUtils.format(params, "utf-8");
                url += "?" + paramString;
                HttpGet httpGet = new HttpGet(url);
 
                HttpResponse httpResponse = httpClient.execute(httpGet);
                HttpEntity httpEntity = httpResponse.getEntity();
                is = httpEntity.getContent();
            }          
 
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
 
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            json = sb.toString();
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }
 
        // try parse the string to a JSON object
        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());
        }
 
        // return JSON String
        return jObj;
 
    }
}
package com.example.attendance;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends Activity {
	Button sem3a;
	Button sem3b;
	Button sem4a;
	Button sem4b;
	Button sem5a;
	Button sem5b;
	Button sem6a;
	Button sem6b;
	Button sem7a;
	Button sem7b;
	Button sem8a;
	Button sem8b;
	
	public static final String IP="com.example.Attendance.IP";
	public String ip;
	
	public static final String SEM="com.example.Notifications.SEM";
	public String sem;
	
	public static final String SEC="com.example.Notifications.SEC";
	public String sec;
	
	
	
	@SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 
        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		sem3a=(Button)findViewById(R.id.sem3a);
		sem3a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
                Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="3";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem3b=(Button)findViewById(R.id.sem3b);
		sem3b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="3";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem4a=(Button)findViewById(R.id.sem4a);
		sem4a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="4";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });

		sem4b=(Button)findViewById(R.id.sem4b);
		sem4b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="4";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });

		sem5a=(Button)findViewById(R.id.sem5a);
		sem5a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="5";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });

		sem5b=(Button)findViewById(R.id.sem5b);
		sem5b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="5";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
	
		sem6a=(Button)findViewById(R.id.sem6a);
		sem6a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="6";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem6b=(Button)findViewById(R.id.sem6b);
		sem6b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="6";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem7a=(Button)findViewById(R.id.sem7a);
		sem7a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="7";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem7b=(Button)findViewById(R.id.sem7b);
		sem7b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="7";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem8a=(Button)findViewById(R.id.sem8a);
		sem8a.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="8";
                sec="A";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
		
		sem8b=(Button)findViewById(R.id.sem8b);
		sem8b.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            		Intent i = new Intent(getApplicationContext(), GetStudentList.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	ip=edtxtIp.getText().toString();
            	
                sem="8";
                sec="B";
                i.putExtra(IP, ip);
                i.putExtra(SEM, sem);
                i.putExtra(SEC,sec);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
package com.example.attendance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.webkit.WebView;

public class ShowResult extends Activity {

	private WebView webView;
	public String url_result;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show_result);

		Intent intent = getIntent();
		url_result = intent.getStringExtra(GetStudentList.URL);
		
		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl(url_result);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_result, menu);
		return true;
	}

}
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
    android:orientation="vertical">
    <!-- Main ListView
         Always give id value as list(@android:id/list)
    -->
    <ListView
        android:id="@android:id/list"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"/>

    <WebView
        android:id="@+id/webView1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" />
 
</LinearLayout>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/LinearLayout1"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="fill_horizontal"
    android:orientation="vertical"
    android:padding="20dp"
    tools:context=".MainActivity" >

    <LinearLayout
        android:id="@+id/semester3"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center_horizontal|fill_horizontal"
        android:orientation="horizontal" >

        <Button
            android:id="@+id/sem3a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 3 A" />
         <Button
            android:id="@+id/sem3b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 3 B" />
    </LinearLayout>
    <LinearLayout
        android:id="@+id/semester4"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" 
        android:orientation="horizontal">

        <Button
            android:id="@+id/sem4a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 4 A" />
         <Button
            android:id="@+id/sem4b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 4 B" />
    </LinearLayout>
    <LinearLayout
        android:id="@+id/semester5"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" 
        android:orientation="horizontal">

        <Button
            android:id="@+id/sem5a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 5 A" />
         <Button
            android:id="@+id/sem5b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 5 B" />
    </LinearLayout>
    <LinearLayout
        android:id="@+id/semester6"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" 
        android:orientation="horizontal">

        <Button
            android:id="@+id/sem6a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 6 A" />
         <Button
            android:id="@+id/sem6b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 6 B" />
    </LinearLayout>
    <LinearLayout
        android:id="@+id/semester7"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" 
        android:orientation="horizontal">

        <Button
            android:id="@+id/sem7a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 7 A" />
         <Button
            android:id="@+id/sem7b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 7 B" />
    </LinearLayout>
    <LinearLayout
        android:id="@+id/semester8"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" 
        android:orientation="horizontal">

        <Button
            android:id="@+id/sem8a"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 8 A" />
         <Button
            android:id="@+id/sem8b"
            style="?android:attr/buttonStyleSmall"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEM 8 B" />
    </LinearLayout>




    <EditText
        android:id="@+id/editText1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10" >

        <requestFocus />
    </EditText>

</LinearLayout>
<?xml version="1.0" encoding="utf-8"?>
<WebView  xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/webView1"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
/>
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:background="@drawable/background">
  <!-- android:background="@drawable/background" > -->

    <LinearLayout
        android:id="@+id/usnroll"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content" >

        <TextView
            android:id="@+id/rollno"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:textSize="20dip"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/usn"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:paddingLeft="6dip"
            android:paddingTop="6dip"
            android:textSize="17dip"
            android:textStyle="bold" />
        
    </LinearLayout>

    <TextView
        android:id="@+id/name"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:paddingLeft="6dip"
        android:paddingTop="6dip"
        android:textSize="15dip" />



</LinearLayout>
<?xml version="1.0" encoding="utf-8"?><menu xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Single menu item
         Set id, icon and Title for each menu item
    -->
    <item android:id="@+id/finalSubmit"
          android:title="SUBMIT" />
    <item android:id="@+id/showSelection"
          android:title="SHOW"/>

 
</menu>
package com.example.changepassccode;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.webkit.WebView;

public class Change extends Activity {
	
	public String ip,op,np,url_change;
	
	WebView webView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_change);
		Intent intent = getIntent();
		ip = intent.getStringExtra(MainActivity.IP);
		op=intent.getStringExtra(MainActivity.OP);
		np=intent.getStringExtra(MainActivity.NP);
		
		url_change = "http://"+ip+"/attendance/changePasscode.php?op="+op+"&np="+np;
		
		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl(url_change);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.change, menu);
		return true;
	}

}
package com.example.changepassccode;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
	public static final String IP="com.example.changepasscode.IP";
	public static final String NP="com.example.changepasscode.NP";
	public static final String OP="com.example.changepasscode.OP";
	
	Button change;
	String ip,op,np,vp;

	@SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 
        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		change=(Button)findViewById(R.id.button1);
		change.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
                Intent i = new Intent(getApplicationContext(), Change.class);
            		//showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
                
                EditText edtxtop=(EditText)findViewById(R.id.editText1);
                EditText edtxtnp=(EditText)findViewById(R.id.editText2);
                EditText edtxtvp=(EditText)findViewById(R.id.editText3);
                EditText edtxtIp=(EditText)findViewById(R.id.editText4);
                 np=edtxtnp.getText().toString();
                 vp=edtxtvp.getText().toString();
                 op=edtxtop.getText().toString();
                 ip=edtxtIp.getText().toString();
                 
                 if(np.equals(vp)){
                	 i.putExtra(IP, ip);
                	 i.putExtra(OP, op);
                	 i.putExtra(NP, np);
                	 startActivity(i);
                 }
                 else
                	 showAlertDialog(MainActivity.this,"NOT MATCH","NEW AND VERIFY PASSCODE DO NOT MATCH",false);
            	}
            	else
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            }
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/LinearLayout1"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:paddingBottom="@dimen/activity_vertical_margin"
    android:paddingLeft="@dimen/activity_horizontal_margin"
    android:paddingRight="@dimen/activity_horizontal_margin"
    android:paddingTop="@dimen/activity_vertical_margin"
    tools:context=".MainActivity" >

    <EditText
        android:id="@+id/editText1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="old passcode" >

        <requestFocus />
    </EditText>

    <EditText
        android:id="@+id/editText2"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="new passcode" />

    <EditText
        android:id="@+id/editText3"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="verify code" />

    <EditText
        android:id="@+id/editText4"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:ems="10"
        android:hint="ip" />

    <Button
        android:id="@+id/button1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="CHANGE" />

</LinearLayout>

<?xml version="1.0" encoding="utf-8"?>
<WebView  xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/webView1"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
/>
package com.example.notifications;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class GetNotifications extends ListActivity {
	
	private ProgressDialog pDialog;
	 
    JSONParser jParser = new JSONParser();
 
    ArrayList<HashMap<String, String>> notificationList;
  
    public String url_all_notifications;
    
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_NOTIFICATIONS = "notifications";
    private static final String TAG_SUBJECT= "subject";
    private static final String TAG_CONTENT = "content";
    private static final String TAG_TIME="time";
 
    JSONArray notifications = null;
    
    public void displayToast(String s){
		 Toast.makeText(this, s, Toast.LENGTH_LONG).show();
	 }

    public void displayAlert(String s){
    	new AlertDialog.Builder(this)
        .setTitle("CONTENT")
        .setMessage(s)
        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) { 
                // continue with delete
            }
         })
         .show();
    	
    }
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_get_notifications);
		
		Intent intent = getIntent();
		String current_ip = intent.getStringExtra(MainActivity.IP);
		
		url_all_notifications = "http://"+current_ip+"/mysqlTest/getNotifications.php";
		
		notificationList = new ArrayList<HashMap<String, String>>();
		
        new LoadAllNotifications().execute();
		
		 ListView lv = getListView();
		 
		 lv.setOnItemClickListener(new OnItemClickListener() {
		 @Override
         public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
       
             String su = ((TextView) view.findViewById(R.id.content)).getText()
                     .toString();
             
             displayAlert(su);
		 }
     });
		 }
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // if result code 100
        if (resultCode == 100) {
            // if result code 100 is received
            // means user edited/deleted product
            // reload this screen again
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
 
    }
	class LoadAllNotifications extends AsyncTask<String, String, String> {
		 
        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(GetNotifications.this);
            pDialog.setMessage("Loading notifications. Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        
        @Override
		protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            // getting JSON string from URL
            JSONObject json = jParser.makeHttpRequest(url_all_notifications, "GET", params);
 
            // Check your log cat for JSON reponse
            Log.d("All Notifications: ", json.toString());
 
            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);
 
                if (success == 1) {
                    notifications = json.getJSONArray(TAG_NOTIFICATIONS);
 
                    // looping through All Products
                    for (int i = 0; i < notifications.length(); i++) {
                        JSONObject c =notifications.getJSONObject(i);
 
                        // Storing each json item in variable
                        String subject = c.getString(TAG_SUBJECT);
                        String content = c.getString(TAG_CONTENT);
                        String time = c.getString(TAG_TIME);
 
                        // creating new HashMap
                        HashMap<String, String> map = new HashMap<String, String>();
 
                        // adding each child node to HashMap key => value
                        map.put(TAG_SUBJECT, subject);
                        map.put(TAG_CONTENT,content);
                        map.put(TAG_TIME, time);
 
                        // adding HashList to ArrayList
                        notificationList.add(map);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
 
            return null;
        }
 
        /**
         * After completing background task Dismiss the progress dialog
         * **/
        @Override
		protected void onPostExecute(String file_url) {
            // dismiss the dialog after getting all products
            pDialog.dismiss();
            // updating UI from Background Thread
            runOnUiThread(new Runnable() {
                @Override
				public void run() {
                    /**
                     * Updating parsed JSON data into ListView
                     * */
                    ListAdapter adapter = new SimpleAdapter(
                            GetNotifications.this,notificationList,
                            R.layout.list_item, new String[] { TAG_SUBJECT,
                                    TAG_TIME,TAG_CONTENT},
                            new int[] { R.id.subject, R.id.time,R.id.content });
                    // updating listview
                    setListAdapter(adapter);
                }
            });
 
        }
 
    }
}

package com.example.notifications;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
	public static final String IP="com.example.Notifications.IP";
	public String ip;
	
	@SuppressWarnings("deprecation")
	public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
 
        // Setting Dialog Title
        alertDialog.setTitle(title);
 
        // Setting Dialog Message
        alertDialog.setMessage(message);
         
        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);
 
        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            @Override
			public void onClick(DialogInterface dialog, int which) {
            }
        });
 
        // Showing Alert Message
        alertDialog.show();
    }

	Button btnGetNotifications;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnGetNotifications=(Button)findViewById(R.id.button1);
		
		btnGetNotifications.setOnClickListener(new View.OnClickListener() {
			 
            @Override
            public void onClick(View view) {
            	
            	ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
            	 
            	Boolean isInternetPresent = cd.isConnectingToInternet();
            	
            	if(isInternetPresent){
            	EditText edtxtIp=(EditText)findViewById(R.id.editText1);
            	String  ip=edtxtIp.getText().toString();
                Intent i = new Intent(getApplicationContext(), GetNotifications.class);
                
                i.putExtra(IP, ip);
                startActivity(i);
            	}
            	else{
            		showAlertDialog(MainActivity.this,"No internet connection","Please connect to internt",false);
            		
            		
            		
            	}
 
            }
        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.layout.menu, menu);
		return true;
	}
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item){
         
        switch (item.getItemId())
        {
        case R.id.setip:
        	return true;
 
        default:
            return super.onOptionsItemSelected(item);
        }
		
    } 

}
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
    android:orientation="vertical">
    <!-- Main ListView
         Always give id value as list(@android:id/list)
    -->
    <ListView
        android:id="@android:id/list"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"/>
 
</LinearLayout>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:paddingBottom="@dimen/activity_vertical_margin"
    android:paddingLeft="@dimen/activity_horizontal_margin"
    android:paddingRight="@dimen/activity_horizontal_margin"
    android:paddingTop="@dimen/activity_vertical_margin"
    tools:context=".MainActivity" >

    <EditText
        android:id="@+id/editText1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentTop="true"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="45dp"
        android:ems="10" >

        <requestFocus />
    </EditText>

    <Button
        android:id="@+id/button1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_centerHorizontal="true"
        android:layout_centerVertical="true"
        android:text="Get Notifications" />

</RelativeLayout>

<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical" >
 
    <!-- Product id (pid) - will be HIDDEN - used to pass to other activity -->
    <TextView
        android:id="@+id/subject"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content" 
        android:textStyle="bold"
        android:textSize="20dip"/>
 
    <!-- Name Label -->
    <TextView
        android:id="@+id/content"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:paddingTop="6dip"
        android:paddingLeft="6dip"
        android:textSize="17dip"
        android:textStyle="bold" 
        android:visibility="gone"/>
    <TextView
        android:id="@+id/time"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:paddingTop="6dip"
        android:paddingLeft="6dip"
        android:textSize="15dip" />
 
</LinearLayout>
<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Single menu item
         Set id, icon and Title for each menu item
    -->
    <item android:id="@+id/setip"
          android:title="SetIp" />
 
 
</menu>