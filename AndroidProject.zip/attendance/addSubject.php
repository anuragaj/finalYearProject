<?php

$si=$_POST['subjectcode'];
$name=$_POST['subjectname'];
$semester=$_POST['semester'];


	  $username = "root";
      $password = "root";
      $hostname = "localhost"; 
      $query="INSERT INTO subjectDetails values('$si','$name','$semester')";


      $dbhandle = mysql_connect($hostname, $username, $password)
                            or die("Unable to connect to MySQL");
      $selected = mysql_select_db("SIET",$dbhandle)
                            or die("Could not select SIET");

       $result = mysql_query($query);

       echo "SUBJECT ADDED";

       ?>