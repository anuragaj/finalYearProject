<?php            

            date_default_timezone_set('Asia/Kolkata');

            $response=array();

      	$semester=$_GET['sem'];
		$section=$_GET['sec'];
            $USN=$_GET['USN'];
            $name=$_GET['name'];
            $rollno=$_GET['rollno'];
            $subjectCode=$_GET['subjectCode'];
            $date=date('l jS \of F Y h:i:s A');
            $attendance=$_GET['attendance'];

            require_once __DIR__ . '/db_connect.php';

            $db = new DB_CONNECT();

      
            $result=mysql_query("INSERT INTO attendance values('$USN','$subjectCode','$date','$attendance','$rollno')")or die(mysql_error());

              if($result==1){
                     $response["success"] = 1;
                        $response["message"] = "update successful";
                        echo json_encode($response);
            }
            else{
                      $response["success"] = 0;
                        $response["message"] = "update not successful";     
                        echo json_encode($response);

            }


?>