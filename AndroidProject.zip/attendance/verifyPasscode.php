<?php            

			$passcode=$_GET['passcode'];

            $response = array();

            require_once __DIR__ . '/db_connect.php';

            $db = new DB_CONNECT();

            $result=mysql_query("SELECT * FROM staffDetails WHERE passcode='$passcode'")or die(mysql_error("error"));

            if(mysql_num_rows($result) > 0) {
                 $response["lecturer"] = array();
 
                $row = mysql_fetch_array($result);
                      // temp user array
                         $note = array();
                         $note["name"] = $row["Name"];
       
                         // push single product into final response array
                        array_push($response["lecturer"], $note);
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} 
else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "Wrong passcode";
 
    // echo no users JSON

    echo json_encode($response);
}
?>