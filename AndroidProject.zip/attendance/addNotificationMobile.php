<?php

 date_default_timezone_set('Asia/Kolkata');
$subject=$_GET['s'];
$content=$_GET['c'];
$passcode=$_GET['pc'];

//$timezone=date_default_timezone_get();
//date_default_timezone_set($timezone);
//$time = date('m/d/Y h:i:s a', time());
$time=date();

$response = array();

            require_once __DIR__ . '/db_connect.php';

            $db = new DB_CONNECT();

            //echo $subject;
            //echo $content;
            //echo $passcode;

            $result=mysql_query("SELECT * FROM staffDetails WHERE passcode='$passcode'")or die(mysql_error("error"));
             
            $row=mysql_fetch_row($result);

            $name=$row[1];
            //echo $name;
            $subject=$subject."\t"."ADDED BY:".$name;

            if(mysql_num_rows($result) > 0) {


              $result=mysql_query("INSERT INTO notifications values('$subject','$content','$time')")or die(mysql_error("error"));
 
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} 
else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "Wrong passcode";
 
    // echo no users JSON

    echo json_encode($response);
}

       ?>