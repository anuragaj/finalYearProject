<?php

			$sem=$_GET['sem'];
			$sec=$_GET['sec'];
            $sc=$_GET['sc'];

			require_once __DIR__ . '/db_connect.php';

                  $response=array();

            $db = new DB_CONNECT();

            $result=mysql_query("SELECT count from class WHERE semester='$sem' AND section='$sec' AND subjectCode='$sc'") or die (mysql_errno());

            $row=mysql_fetch_row($result);

            $count=$row[0];
            $count=$count+1;

            $result=mysql_query("UPDATE class SET count='$count' WHERE semester='$sem' AND section='$sec' AND subjectCode='$sc'")or die(mysql_error());

            if($result==1){
                     $response["success"] = 1;
                        $response["message"] = "update success";
                        echo json_encode($response);
            }
            else{
                      $response["success"] = 0;
                        $response["message"] = "update not success";     
                        echo json_encode($response);

            }
?>     