<!DOCTYPE html>
 <head>
   <meta charset="utf-8" />
   <link rel="stylesheet" type="text/css" href="./smscss2.css"/>
  </head>
  <body>
   <div id="container">
    <h1>DEPARTMENT OF CSE</h1>
	<h3>Students List</h3>
<table  cellpadding="10" cellspacing="30">
 	<tr align="center">
	<th>USN</th>
	<th>Name</th>
	<th>Semester</th>
	<th>Section</th>
	<th>Roll NO</th>
	</tr>
   <?php
   $username = "root";
      $password = "root";
      $hostname = "localhost"; 
      $query="SELECT * FROM studentDetails ORDER BY semester,section";


      $dbhandle = mysql_connect($hostname, $username, $password)
                            or die("Unable to connect to MySQL");
      $selected = mysql_select_db("SIET",$dbhandle)
                            or die("Could not select SIET");

       $result = mysql_query($query);

while($row=mysql_fetch_row($result))
	echo "<tr>
	<td align='center'>$row[0]</td>
	<td align='center'>$row[1]</td>
	<td align='center'>$row[2]</td>
	<td align='center'>$row[3]</td>
	<td align='center'>$row[4]</td>
	</tr>";
?>

</table>
  </div>
 </body>
</html>