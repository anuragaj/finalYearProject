<?php

$usn=$_POST['usn'];
$name=$_POST['name'];
$semester=$_POST['semester'];
$section=$_POST['section'];
$rollno=$_POST['rollno'];


	  $username = "root";
      $password = "root";
      $hostname = "localhost"; 
      $query="INSERT INTO studentDetails values('$usn','$name','$semester','$section','$rollno')";


      $dbhandle = mysql_connect($hostname, $username, $password)
                            or die("Unable to connect to MySQL");
      $selected = mysql_select_db("SIET",$dbhandle)
                            or die("Could not select SIET");

       $result = mysql_query($query);

       echo "STUDENT ADDED";

       ?>