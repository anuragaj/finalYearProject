<?php

date_default_timezone_set('Asia/Kolkata');

extract($_GET);

//echo $section."\t".$semester."\t".$numberOfStudents."\t".subjectCode;
//echo $su0."\t".$sn0."\t".$sr0."\t".$sa0;


require_once __DIR__ . '/db_connect.php';

$db = new DB_CONNECT();

	$subjectCode=$_GET["subjectCode"];
	$date=date('l jS \of F Y h:i:s A');


      for($i = 0 ; $i<$numberOfStudents ; $i++){
      	$susn="su".$i;
      	$ssa="sa".$i;
      	$ssr="sr".$i;

      	$USN=$_GET[$susn];
      	$attendance=$_GET[$ssa];
      	$rollno=$_GET[$ssr];

      	//echo $USN."\t".$attendance."\t".$rollno."\n";
      
        $result=mysql_query("INSERT INTO attendance values('$USN','$subjectCode','$date','$attendance','$rollno')")or die(mysql_error());
		}

		$sem=$_GET["semester"];
		$sec=$_GET["section"];
		$result=mysql_query("SELECT count from class WHERE semester='$sem' AND section='$sec' AND subjectCode='$subjectCode'") or die (mysql_errno());

        $row=mysql_fetch_row($result);

            $count=$row[0];
            $count=$count+1;

        $result=mysql_query("UPDATE class SET count='$count' WHERE semester='$sem' AND section='$sec' AND subjectCode='$subjectCode'")or die(mysql_error());

echo "succcess";

?>