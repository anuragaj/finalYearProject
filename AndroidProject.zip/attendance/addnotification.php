<?php

date_default_timezone_set("UTC");
$subject=$_POST['subject'];
$content=$_POST['content'];

$timezone=date_default_timezone_get();
date_default_timezone_set($timezone);
$time = date('m/d/Y h:i:s a', time());


	  $username = "root";
      $password = "root";
      $hostname = "localhost"; 
      $query="INSERT INTO notifications values('$subject','$content','$time')";


      $dbhandle = mysql_connect($hostname, $username, $password)
                            or die("Unable to connect to MySQL");
      $selected = mysql_select_db("SIET",$dbhandle)
                            or die("Could not select SIET");

       $result = mysql_query($query);

       echo "NOTIFICATION ADDED";

       ?>