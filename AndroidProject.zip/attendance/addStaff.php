<?php

$staffid=$_POST['staffid'];
$name=$_POST['name'];
$pc=$_POST['passcode'];



	  $username = "root";
      $password = "root";
      $hostname = "localhost"; 
      $query="INSERT INTO staffDetails values('$staffid','$name','$pc')";


      $dbhandle = mysql_connect($hostname, $username, $password)
                            or die("Unable to connect to MySQL");
      $selected = mysql_select_db("SIET",$dbhandle)
                            or die("Could not select SIET");

       $result = mysql_query($query);

       echo "STAFF ADDED";

       ?>