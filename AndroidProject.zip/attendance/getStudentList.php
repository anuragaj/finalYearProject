<?php            

			$sem=$_GET['sem'];
			$sec=$_GET['sec'];

            $response = array();

            require_once __DIR__ . '/db_connect.php';

            $db = new DB_CONNECT();

            $result=mysql_query("SELECT * FROM studentDetails WHERE semester='$sem' AND section='$sec' ORDER BY rollNo")or die(mysql_error("error"));

            if(mysql_num_rows($result) > 0) {
                 $response["students"] = array();
 
                while ($row = mysql_fetch_array($result)) {
                      // temp user array
                         $note = array();
                         $note["usn"] = $row["USN"];
                         $note["name"] = $row["name"];
                         $note["sem"] = $row["semester"];
                         $note["sec"] = $row["section"];
                         $note["rollno"] = $row["rollNo"];
       
                         // push single product into final response array
                        array_push($response["students"], $note);
                    }
                   $result=mysql_query("SELECT * FROM subjectDetails WHERE semester=$sem")or die(mysql_error("error"));
                   if(mysql_num_rows($result) > 0) {
                 $response["subjects"] = array();
 
                while ($row = mysql_fetch_array($result)) {
                      // temp user array
                         $subject = array();
                         $subject["subjectName"] = $row["subjectName"];
                         $subject["subjectCode"] = $row["subjectCode"];
       
                         // push single product into final response array
                        array_push($response["subjects"], $subject);
                    }
                    $result=mysql_query("SELECT * FROM staffDetails")or die(mysql_error("error"));
                   if(mysql_num_rows($result) > 0) {
                 $response["lecturers"] = array();
 
                while ($row = mysql_fetch_array($result)) {
                      // temp user array
                         $staff = array();
                         $staff["name"] = $row["Name"];
                         $staff["passcode"] = $row["passcode"];
       
                         // push single product into final response array
                        array_push($response["lecturers"], $staff);
                    }
                }
    // success
    //$response["notifications"]=array_reverse($response["notifications"]);
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} 
}
else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No students found";
 
    // echo no users JSON

    echo json_encode($response);
}
?>